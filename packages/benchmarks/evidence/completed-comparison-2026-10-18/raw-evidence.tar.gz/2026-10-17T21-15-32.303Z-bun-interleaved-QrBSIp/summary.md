# Current-framework request-count benchmark

Status: complete; valid: true.

1000000 measured requests per framework for a full six-cell matrix (a corrective subset uses its explicit per-cell allocations), with three repeats; warmup and correctness probes excluded. Only the current local Nile build is used. Server and generator share this PC on separate physical CPU cores, including each core's SMT siblings. All selected frameworks finish round 1 before round 2, then round 3; a seeded framework order rotates across rounds. Each trial uses a fresh fixture and database. Corrective selections contain only the explicitly listed scenarios. SQLite uses fresh files, WAL and synchronous NORMAL. Node and Bun use their respective built-in SQLite drivers and are separate runtime tracks.

| Framework | Workload | Validation | Mean successful req/s | Range | Mean trial p95 ms | Requests | Valid |
|---|---|---|---:|---:|---:|---:|---|
| nile | memory-read | plain | 14487.8 | 12221.7–15774.5 | 11.5 | 166668 | true |
| nile | memory-read | validated | 14345.9 | 11967.0–15566.3 | 11.6 | 166668 | true |
| nile | sqlite-read | plain | 12087.9 | 10316.7–13023.3 | 12.6 | 166668 | true |
| nile | sqlite-read | validated | 10939.6 | 9923.8–12887.1 | 13.9 | 166666 | true |
| nile | sqlite-read-write | plain | 6041.7 | 5359.3–6553.1 | 57.5 | 166665 | true |
| nile | sqlite-read-write | validated | 5623.4 | 5068.8–6541.5 | 59.7 | 166665 | true |
| elysia | memory-read | plain | 17330.8 | 14996.7–19163.9 | 9.6 | 166668 | true |
| elysia | memory-read | validated | 18682.8 | 17797.7–19146.0 | 8.1 | 166668 | true |
| elysia | sqlite-read | plain | 17649.7 | 15216.9–18948.7 | 9.1 | 166668 | true |
| elysia | sqlite-read | validated | 16742.9 | 14936.5–18437.5 | 9.7 | 166666 | true |
| elysia | sqlite-read-write | plain | 8632.9 | 8008.8–9048.9 | 39.1 | 166665 | true |
| elysia | sqlite-read-write | validated | 8721.2 | 7768.2–9372.0 | 36.8 | 166665 | true |
| effect | memory-read | plain | 14819.5 | 13303.6–16127.1 | 11.6 | 166668 | true |
| effect | memory-read | validated | 15478.5 | 12994.9–16739.8 | 10.9 | 166668 | true |
| effect | sqlite-read | plain | 13133.8 | 10948.2–14374.8 | 11.9 | 166668 | true |
| effect | sqlite-read | validated | 10483.7 | 9357.5–11470.8 | 15.6 | 166666 | true |
| effect | sqlite-read-write | plain | 5994.3 | 5861.0–6119.9 | 52.3 | 166665 | true |
| effect | sqlite-read-write | validated | 5990.7 | 5285.8–7206.6 | 59.7 | 166665 | true |

Trial quantiles are averaged across repeats, not pooled. Closed-loop timing can hide queued demand; these results do not establish a universal fastest-framework claim. Background CPU and swap samples, raw response counters, workload metadata and process telemetry accompany each cell. Warmups use the same DB file as their following measured work. The ordering description above states whether fresh seeds apply per cell or per round. Durable SQLite write performance can dominate framework differences.
