# Current-framework request-count benchmark

Status: complete; valid: true.

1000000 measured requests per framework for a full six-cell matrix (a corrective subset uses its explicit per-cell allocations), with three repeats; warmup and correctness probes excluded. Only the current local Nile build is used. Server and generator share this PC on separate physical CPU cores, including each core's SMT siblings. All selected frameworks finish round 1 before round 2, then round 3; a seeded framework order rotates across rounds. Each trial uses a fresh fixture and database. Corrective selections contain only the explicitly listed scenarios. SQLite uses fresh files, WAL and synchronous NORMAL. Node and Bun use their respective built-in SQLite drivers and are separate runtime tracks.

| Framework | Workload | Validation | Mean successful req/s | Range | Mean trial p95 ms | Requests | Valid |
|---|---|---|---:|---:|---:|---:|---|
| nile | memory-read | plain | 5127.4 | 4618.4–5386.9 | 26.7 | 166668 | true |
| nile | memory-read | validated | 5330.7 | 5184.5–5447.7 | 22.1 | 166668 | true |
| nile | sqlite-read | plain | 4384.1 | 4144.6–4524.8 | 29.1 | 166668 | true |
| nile | sqlite-read | validated | 4178.0 | 4000.7–4531.3 | 33.5 | 166666 | true |
| nile | sqlite-read-write | plain | 2941.5 | 2914.1–2989.0 | 82.7 | 166665 | true |
| nile | sqlite-read-write | validated | 2679.7 | 2653.3–2703.1 | 89.6 | 166665 | true |
| elysia | sqlite-read-write | validated | 3616.5 | 3441.1–3742.1 | 73.4 | 166665 | true |
| express | sqlite-read-write | plain | 2848.8 | 2725.6–3027.0 | 77.1 | 166665 | true |
| express | sqlite-read-write | validated | 2566.5 | 2394.5–2661.1 | 92.4 | 166665 | true |
| fastify | sqlite-read | plain | 10575.9 | 10418.9–10688.7 | 13.5 | 166668 | true |
| fastify | sqlite-read | validated | 9719.4 | 8300.1–10468.9 | 14.5 | 166666 | true |
| fastify | sqlite-read-write | plain | 4826.3 | 4635.0–5084.5 | 68.3 | 166665 | true |
| fastify | sqlite-read-write | validated | 4803.3 | 4668.0–4986.6 | 62.7 | 166665 | true |
| trpc | memory-read | plain | 2143.0 | 2118.3–2188.5 | 64.9 | 166668 | true |
| trpc | memory-read | validated | 2133.0 | 2102.9–2188.2 | 59.8 | 166668 | true |
| trpc | sqlite-read-write | plain | 1546.4 | 1521.1–1559.9 | 109.9 | 166665 | true |
| trpc | sqlite-read-write | validated | 1498.2 | 1481.2–1530.5 | 113.7 | 166665 | true |
| nest-express | sqlite-read | plain | 3563.7 | 3307.3–3723.6 | 36.6 | 166668 | true |
| nest-express | sqlite-read | validated | 3350.1 | 3265.2–3497.0 | 41.4 | 166666 | true |
| nest-express | sqlite-read-write | validated | 2442.8 | 2309.3–2513.1 | 88.7 | 166665 | true |
| nest-fastify | sqlite-read | plain | 8907.2 | 8714.6–9158.1 | 15.1 | 166668 | true |
| nest-fastify | sqlite-read | validated | 8034.5 | 7029.6–8649.6 | 17.6 | 166666 | true |
| nest-fastify | sqlite-read-write | validated | 4530.8 | 4384.6–4663.0 | 70.0 | 166665 | true |
| adonis | sqlite-read-write | plain | 3551.1 | 3518.3–3579.9 | 74.5 | 166665 | true |
| adonis | sqlite-read-write | validated | 3171.8 | 2936.4–3383.1 | 80.7 | 166665 | true |
| effect | memory-read | plain | 9718.9 | 9597.1–9851.0 | 18.4 | 166668 | true |
| effect | memory-read | validated | 9455.3 | 9403.1–9538.1 | 18.9 | 166668 | true |
| effect | sqlite-read | plain | 7486.7 | 7143.7–7684.0 | 23.0 | 166668 | true |
| effect | sqlite-read | validated | 7037.2 | 6245.8–7458.9 | 26.0 | 166666 | true |
| effect | sqlite-read-write | validated | 4117.7 | 4065.6–4162.9 | 72.6 | 166665 | true |
| encore | sqlite-read-write | plain | 1741.7 | 1712.3–1770.7 | 100.6 | 166665 | true |
| encore | sqlite-read-write | validated | 1720.3 | 1685.4–1750.5 | 105.2 | 166665 | true |

Trial quantiles are averaged across repeats, not pooled. Closed-loop timing can hide queued demand; these results do not establish a universal fastest-framework claim. Background CPU and swap samples, raw response counters, workload metadata and process telemetry accompany each cell. Warmups use the same DB file as their following measured work. The ordering description above states whether fresh seeds apply per cell or per round. Durable SQLite write performance can dominate framework differences.
