# Current-framework request-count benchmark

Status: incomplete; valid: false.

1000000 measured requests per framework across six cells and three repeats; warmup and correctness probes excluded. Only the current local Nile build is used. Server and generator share this PC on separate physical CPU cores, including each core's SMT siblings. Framework order is seeded and randomized per cell; repeats are contiguous within a cell. SQLite uses fresh files, WAL and synchronous NORMAL. Node and Bun use their respective built-in SQLite drivers and are separate runtime tracks.

| Framework | Workload | Validation | Mean successful req/s | Range | Mean trial p95 ms | Requests | Valid |
|---|---|---|---:|---:|---:|---:|---|
| express | memory-read | plain | 5232.4 | 4937.7–5438.0 | 27.4 | 166668 | true |
| adonis | memory-read | plain | 7420.8 | 7358.3–7455.9 | 16.4 | 166668 | true |
| encore | memory-read | plain | 1984.5 | 1963.2–2001.3 | 68.8 | 166668 | true |
| nest-fastify | memory-read | plain | 10741.2 | 10171.7–11108.0 | 14.0 | 166668 | true |
| fastify | memory-read | plain | 13097.0 | 11819.2–13753.8 | 11.8 | 166668 | true |
| effect | memory-read | plain | 4865.3 | 4547.2–5150.3 | 44.3 | 166668 | true |
| elysia | memory-read | plain | 7839.1 | 7800.3–7903.0 | 16.0 | 166668 | true |
| nest-express | memory-read | plain | 4258.1 | 4015.1–4493.8 | 35.0 | 166668 | true |
| nile | memory-read | plain | 5428.2 | 5224.6–5550.6 | 24.4 | 166668 | true |
| trpc | memory-read | plain | 2192.1 | 2142.2–2235.9 | 60.7 | 166668 | true |
| nile | memory-read | validated | 4997.5 | 4625.2–5184.1 | 26.5 | 166668 | true |
| fastify | memory-read | validated | 13308.5 | 13216.4–13470.1 | 11.8 | 166668 | true |
| nest-express | memory-read | validated | 4169.0 | 4056.1–4332.6 | 34.0 | 166668 | true |
| adonis | memory-read | validated | 6884.3 | 6790.1–6941.2 | 17.6 | 166668 | true |
| nest-fastify | memory-read | validated | 9959.6 | 9356.1–10863.9 | 15.0 | 166668 | true |
| encore | memory-read | validated | 1964.9 | 1949.2–1993.2 | 69.8 | 166668 | true |
| effect | memory-read | validated | 9459.7 | 9385.7–9564.4 | 18.9 | 166668 | true |
| express | memory-read | validated | 4951.2 | 4572.5–5173.8 | 28.3 | 166668 | true |
| elysia | memory-read | validated | 7408.1 | 6699.2–7824.9 | 19.6 | 166668 | true |
| trpc | memory-read | validated | 1462.6 | 1093.2–2137.2 | 128.5 | 166668 | true |
| nest-express | sqlite-read | plain | 2389.8 | 2145.8–2727.6 | 75.7 | 166668 | true |
| fastify | sqlite-read | plain | 7231.8 | 5339.3–8305.9 | 21.8 | 166668 | true |
| nest-fastify | sqlite-read | plain | 6463.4 | 5649.0–6882.7 | 23.3 | 166668 | true |
| encore | sqlite-read | plain | 1920.8 | 1887.7–1964.2 | 72.5 | 166668 | true |
| adonis | sqlite-read | plain | 4398.8 | 3927.1–4657.9 | 31.1 | 166668 | true |
| effect | sqlite-read | plain | 6165.3 | 6135.4–6183.9 | 27.6 | 166668 | true |
| elysia | sqlite-read | plain | 4774.8 | 4532.5–4920.9 | 27.1 | 166668 | true |
| nile | sqlite-read | plain | 3346.1 | 3182.1–3474.6 | 37.2 | 166668 | true |
| express | sqlite-read | plain | 3192.3 | 3032.3–3342.3 | 45.2 | 166668 | true |
| trpc | sqlite-read | plain | 1643.0 | 1596.7–1675.4 | 73.2 | 166668 | true |
| adonis | sqlite-read | validated | 4018.3 | 3965.5–4077.3 | 30.7 | 166666 | true |
| effect | sqlite-read | validated | 4483.8 | 4269.0–4910.5 | 45.1 | 166666 | true |
| elysia | sqlite-read | validated | 4668.1 | 4337.0–4888.5 | 29.4 | 166666 | true |
| nest-fastify | sqlite-read | validated | 6499.5 | 6119.9–6763.1 | 20.9 | 166666 | true |
| encore | sqlite-read | validated | 1956.5 | 1923.0–1981.0 | 69.0 | 166666 | true |
| nile | sqlite-read | validated | 3124.2 | 3034.3–3185.8 | 46.8 | 166666 | true |
| express | sqlite-read | validated | 3144.2 | 3041.0–3255.3 | 43.5 | 166666 | true |
| nest-express | sqlite-read | validated | 2776.6 | 2689.2–2847.0 | 47.2 | 166666 | true |
| fastify | sqlite-read | validated | 8239.5 | 8191.3–8291.9 | 15.8 | 166666 | true |
| trpc | sqlite-read | validated | 1582.7 | 1565.5–1599.7 | 77.1 | 166666 | true |
| elysia | sqlite-read-write | plain | 2853.7 | 2646.8–2975.1 | 102.6 | 166665 | true |
| nest-express | sqlite-read-write | plain | 1882.8 | 1830.8–1941.7 | 129.7 | 166665 | true |
| nile | sqlite-read-write | plain | 2496.8 | 2255.0–2668.7 | 71.2 | 166665 | true |
| adonis | sqlite-read-write | plain | 2745.9 | 2279.1–3004.8 | 75.9 | 166665 | true |
| nest-fastify | sqlite-read-write | plain | 3966.1 | 3919.9–3999.7 | 72.8 | 166665 | true |
| effect | sqlite-read-write | plain | 3674.9 | 3633.9–3735.9 | 73.2 | 166665 | true |
| express | sqlite-read-write | plain | 2176.1 | 1929.8–2333.6 | 90.9 | 166665 | true |
| fastify | sqlite-read-write | plain | — | — | — | — | incomplete |

Trial quantiles are averaged across repeats, not pooled. Closed-loop timing can hide queued demand; these results do not establish a universal fastest-framework claim. Background CPU and swap samples, raw response counters, workload metadata and process telemetry accompany each cell. Warmups use the same DB file as measured work; each cell starts from a fresh seed. Durable SQLite write performance can dominate framework differences.
